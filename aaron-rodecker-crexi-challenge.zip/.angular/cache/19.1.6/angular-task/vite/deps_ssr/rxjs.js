import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-T4XHMJL2.js";
import "./chunk-YHCV7DAQ.js";
export default require_cjs();
