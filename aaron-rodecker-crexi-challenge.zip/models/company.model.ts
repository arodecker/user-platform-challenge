export interface Company{
    name: string;
    catchPhrase: string | null;
    bs: string | null;
}