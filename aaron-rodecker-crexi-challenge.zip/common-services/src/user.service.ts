import { } from '@angular/common';
import { Injectable} from '@angular/core';

@Injectable()
export class UserService {

    constructor() {


      }
}